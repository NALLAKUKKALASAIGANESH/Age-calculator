import './App.css';
import Agecalculator from './components/Agecalculator';

function App() {
  return (
    <div className="App">
      <Agecalculator/>
    </div>
  );
}

export default App;
